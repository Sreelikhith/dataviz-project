import * as d3 from 'd3';

export const viz = (svg, props) => {
  const {
    data,
    xValue,
    yValue,
    xAxisLabelText,
    yAxisLabelText,
    marginLeft,
    marginTop,
    marginRight,
    marginBottom,
    width,
    height,
    innerRectFill
  } = props;

  svg.selectAll("*").remove();

  const innerWidth = width - marginLeft - marginRight;
  const innerHeight = height - marginTop - marginBottom;

  const colorScale = d3.scaleLinear()
    .domain([0, d3.max(data, yValue)])
    .range(["#0FFAAC", "#FA5105"]);

  const xScale = d3.scaleBand()
    .domain(data.map(d => xValue(d)))
    .range([0, innerWidth])
    .padding(0.1);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(data, d => yValue(d))])
    .nice()
    .range([innerHeight, 0]);

  const g = svg.append('g')
    .attr('transform', `translate(${marginLeft},${marginTop})`);

  const tooltip = d3.select('body').append('div')
    .attr('class', 'tooltip');

  const yAxisG = g.append('g').call(d3.axisLeft(yScale));
  yAxisG.append('text')
    .attr('class', 'axis-label')
    .attr('transform', 'rotate(-90)')
    .attr('y', -60)
    .attr('x', -innerHeight / 2)
    .attr('fill', 'black')
    .attr('text-anchor', 'middle')
    .style('font-weight', 'bold')
    .style('font-size', '15px')
    .text(yAxisLabelText);

  const xAxisG = g.append('g').call(d3.axisBottom(xScale))
    .attr('transform', `translate(0,${innerHeight})`);
  xAxisG.selectAll('.tick text')
    .attr('transform', 'rotate(-40)')
    .attr('text-anchor', 'end');

  xAxisG.append('text')
    .attr('class', 'axis-label')
    .attr('y', 130)
    .attr('x', innerWidth / 2)
    .attr('fill', 'black')
    .style('font-weight', 'bold')
    .style('font-size', '15px')
    .text(xAxisLabelText);

  g.selectAll('.bar')
    .data(data)
    .enter().append('rect')
      .attr('class', 'bar')
      .attr('x', d => xScale(xValue(d)))
      .attr('width', xScale.bandwidth())
      .attr('y', d => yScale(yValue(d)))
      .attr('height', d => innerHeight - yScale(yValue(d)))
      .attr('fill', d => colorScale(yValue(d)))
      .on('mouseover', (event, d) => {
        tooltip.transition()
          .duration(200)
          .style('opacity', .9);
        tooltip.html(`Job Title: ${xValue(d)}<br/>Avg Salary: $${yValue(d).toFixed(2)}`)
          .style('left', (event.pageX + 5) + 'px')
          .style('top', (event.pageY - 28) + 'px');
      })
      .on('mouseout', () => {
        tooltip.transition()
          .duration(500)
          .style('opacity', 0);
      })
      .on('click', (event, d) => {
        openModalOrRedirect(d);
      });
};

function openModalOrRedirect(dataItem) {
  const modalContent = `Job Title: ${dataItem.job_title}<br/>
                        Average Salary: $${dataItem.avgSalary.toFixed(2)}<br/>
                        More details here...`;
  const modal = document.createElement('div');
  modal.innerHTML = `<div class="modal">
                       <h1>Details</h1>
                       <p>${modalContent}</p>
                       <button onclick="this.parentNode.parentNode.removeChild(this.parentNode)">Close</button>
                     </div>`;
  document.body.appendChild(modal);
}
