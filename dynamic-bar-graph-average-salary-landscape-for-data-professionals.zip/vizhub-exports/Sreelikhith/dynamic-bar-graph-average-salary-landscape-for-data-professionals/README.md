## OverView

This project delivers an interactive visualization of the data field job market 
by utilizing a comprehensive dataset with details on job titles, categories, salaries 
(in both local currencies and USD), employee residences, company locations, experience 
levels, employment types, work settings, and company sizes. Spanning several years and 
encompassing a broad spectrum of positions within the global data science and analytics 
industry, it employs D3.js to facilitate dynamic user interaction. Users can filter and 
explore specific data points such as salary variations, company sizes, job categories, 
and employment types, thereby gaining valuable insights into the evolving trends and 
patterns within the sector.

Dataset:[Jobs In DataScience](https://www.kaggle.com/datasets/hummaamqaasim/jobs-in-data)

## Features

**Interactive Filters**: Users can apply filters to explore data based on job categories, 
experience levels, company sizes, employment types, work settings, and geographical 
locations.

**Dynamic Visualization**: The visualization updates on user-selected filters, displaying
relevant data points such as average salaries and employment distributions.

**Responsive Design**: Ensures a seamless user experience across various devices and 
screen sizes. Tooltips and clickable elements provide additional information and insights, 
enhancing user engagement and understanding.

## Analysis and Insights

**Average Salary by Company Size**:
The bar chart indicates that larger companies (L) tend to offer higher average salaries 
compared to medium (M) and small (S) companies. This could reflect the financial 
capabilities of larger organizations and potentially their demand for more experienced or 
specialized professionals.

**Average Salary by Job Category and Experience Level**:
The graph reveals that average salaries vary significantly across different job 
categories and experience levels. Generally, senior-level positions command higher 
salaries across all job categories. This trend underscores the value of experience 
in the data field.

Certain job categories, such as Data Science and Research, tend to offer higher average 
salaries, indicating a premium on specialized analytical skills.

**Distribution of Employment Types**:
It shows a dominant preference for Full-time employment, comprising a significant 
majority of the employment types in the data field. This suggests that stable, 
full-time roles are the norm within this industry, with part-time, contract, and 
freelance positions making up a smaller portion of the market.

**Salary Variations**:
By selecting different job categories and experience levels, users can observe 
how average salaries vary across the data field. This feature sheds light on the 
premium placed on certain skills and experience levels within the industry.

**Geographical Trends**:
Users can explore geographical distributions of jobs and employee residences, 
identifying trends such as remote work prevalence and regional job market saturation.

**Employment Types and Work Settings**:
The distribution of employment types (full-time, part-time, contract) and 
work settings (remote, in-person, hybrid) can be examined across various regions and 
job categories, highlighting flexibility and work culture trends within the data field.

## The project is designed to address the outlined tasks and questions effectively.

1. **How Does the Average Salary Vary Across Different Job Categories and Experience Levels**

   Our visualization incorporates filters for job categories and experience levels. By allowing
   users to select specific categories and experience levels, the visualization dynamically updates
   to display the average salary associated with the selected criteria.

   The dynamic update is likely achieved through the updateChart function,
   which filters the data based on user selections and recalculates the average
   salary for the remaining dataset. The visualization then redraws the chart,
   specifically showing average salaries by job titles within the chosen
   categories and experience levels. This approach enables users to explore
   salary variations across different job categories and experience levels
   in an interactive manner.

2. **Correlation Between Company Size and Salary Ranges**

   We have implemented a filter for company size, allowing users to explore
   how salary ranges vary across small, medium, and large companies.
   This direct comparison can visually indicate if larger companies tend to
   offer higher salaries than smaller ones, thereby suggesting a correlation
   between company size and salary range.


3. **Geographical Patterns in Job Locations Versus Employee Residences**

   The filters for "Employee Residence" enable users to investigate geographical patterns.
   This mechanism allows for the exploration of where jobs are located
   in relation to where employees live. By filtering the dataset for specific
   locations and comparing the distribution of job locations with employee
   residences, users can identify trends, such as whether certain regions
   have a higher concentration of remote jobs or if certain job categories
   are more prevalent in specific geographical areas.


4. **Distribution of Employment Types and Work Settings Across Regions and Job Categories**

   This visualization includes filters for employment types (full-time, part-time, contract) and
   work settings (remote, in-person, hybrid). This setup enables users to examine how these aspects
   vary across different regions and job categories. Selecting specific employment types or work
   settings updates the visualization to reflect the distribution of these criteria within the
   chosen regions or job categories.

## Interactive Visualization

"Our project goes beyond static charts; it invites users to dive into the data, 
fostering a deeper understanding through exploration and interaction. Each filter 
and selection provides new insights, revealing the multifaceted nature of the data job market. 
This level of engagement not only enhances comprehension but also makes the exploration process 
both enlightening and enjoyable."

## Closing Remarks

"In conclusion, this visualization project serves as a powerful tool for anyone interested in the 
dynamics of the data job market. Whether you're a job seeker, an employer, or simply curious about 
data-related employment trends, our interactive visualization provides valuable insights into salary 
variations, employment types, and geographical distributions. Thank you for your attention, and 
I encourage you to explore the visualization for yourself to uncover the many insights it holds."
   
