The
[Jobs In DataScience](https://www.kaggle.com/datasets/hummaamqaasim/jobs-in-data),

we can do analysis like

1. How distribution of salaries across different data
   science job roles.
2. How does experience level impact salary in the data
   science field?
3. Has there been a change in the popularity of certain data
   science roles over recent years?
4. Which skills are most frequently mentioned in job
   descriptions, and how do they correlate with offered
   salaries?
