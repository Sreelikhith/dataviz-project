import data from './data1.csv';
console.log(data);
for (const d of data) {
  d.work_year = +d.work_year;
  d.salary = +d.salary;
  d.salary_in_usd = +d.salary_in_usd;
}

export const main = (container) => {
  const fontSize = 28;

  const json = JSON.stringify(data[0], null, 2);

  container.innerHTML = `
    <pre style="font-size: ${fontSize}px;">${json}</pre>
  `;
};

export { data };
