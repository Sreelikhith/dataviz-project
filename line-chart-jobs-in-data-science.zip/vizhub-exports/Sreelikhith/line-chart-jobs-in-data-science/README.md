A simple line chart with D3 showing the
