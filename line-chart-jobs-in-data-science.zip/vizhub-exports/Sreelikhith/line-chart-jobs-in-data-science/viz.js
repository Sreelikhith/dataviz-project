import {
  scaleBand,
  scaleLinear,
  max,
  axisLeft,
  axisBottom,
  select,
  mean,
  group,
  line,
} from 'd3';

export const viz = (
  svg,
  {
    data,
    xValue,
    xAxisLabelText,
    xAxisLabelOffset,
    yValue,
    yAxisLabelText,
    yAxisLabelOffset,
    circleRadius,
    circleOpacity,
    marginLeft,
    marginTop,
    marginRight,
    marginBottom,
    width,
    height,
  },
) => {
  svg
    .append('rect')
    .attr('width', width)
    .attr('height', height)
    .attr('fill', '#f0f0f0'); 

  const averageSalaries = Array.from(
    group(data, xValue),
    ([job_category, array]) => ({
      job_category,
      salary_in_usd: mean(array, yValue),
    }),
  );

  const xScale = scaleBand()
    .domain(averageSalaries.map((d) => d.job_category))
    .range([marginLeft, width - marginRight])
    .padding(0.2);

  const yScale = scaleLinear()
    .domain([
      0,
      max(averageSalaries, (d) => d.salary_in_usd),
    ])
    .range([height - marginBottom, marginTop]);

  const xAxis = axisBottom(xScale);
  const xAxisG = svg
    .append('g')
    .attr(
      'transform',
      `translate(0,${height - marginBottom})`,
    )
    .call(xAxis);

  xAxisG
    .selectAll('text')
    .style('text-anchor', 'end')
    .attr('dx', '-0.8em')
    .attr('dy', '0.15em')
    .attr('transform', 'rotate(-15)')
    .attr('font-size', '10px');

  svg
    .append('text')
    .attr('x', width / 2)
    .attr('y', height - 6)
    .attr('fill', 'black')
    .style('text-anchor', 'middle')
    .style('font-weight', 'bold')
    .text(xAxisLabelText);

  const yAxis = axisLeft(yScale);
  const yAxisG = svg
    .append('g')
    .attr('transform', `translate(${marginLeft},0)`)
    .call(yAxis);

  svg
    .append('text')
    .attr('transform', 'rotate(-90)')
    .attr('y', 16)
    .attr('x', -height / 2)
    .attr('fill', 'black')
    .style('text-anchor', 'middle')
    .style('font-weight', 'bold')
    .text(yAxisLabelText);

  const lineGenerator = line()
    .x(
      (d) =>
        xScale(d.job_category) + xScale.bandwidth() / 2,
    )
    .y((d) => yScale(d.salary_in_usd));

  svg
    .append('path')
    .datum(averageSalaries)
    .attr('fill', 'none')
    .attr('stroke', 'steelblue')
    .attr('stroke-width', 2)
    .attr('d', lineGenerator);

  svg
    .selectAll('.point')
    .data(averageSalaries)
    .enter()
    .append('circle')
    .attr('class', 'point')
    .attr(
      'cx',
      (d) =>
        xScale(d.job_category) + xScale.bandwidth() / 2,
    )
    .attr('cy', (d) => yScale(d.salary_in_usd))
    .attr('r', circleRadius)
    .attr('fill', 'steelblue')
    .attr('opacity', circleOpacity)
    .on('mouseover', function (event, d) {
      select(this)
        .transition()
        .duration(150)
        .attr('r', circleRadius * 1.5)
        .attr('fill', 'orange');

      svg
        .append('text')
        .attr('id', 'tooltip')
        .attr(
          'x',
          xScale(d.job_category) + xScale.bandwidth() / 2,
        )
        .attr('y', yScale(d.salary_in_usd) - 10)
        .attr('text-anchor', 'middle')
        .attr('font-size', '12px')
        .attr('fill', 'black')
        .text(`$${d.salary_in_usd.toFixed(2)}`);
    })
    .on('mouseout', function (event, d) {
      select(this)
        .transition()
        .duration(150)
        .attr('r', circleRadius)
        .attr('fill', 'steelblue');

      svg.select('#tooltip').remove();
    });
};