import { select } from 'd3';
import { viz } from './viz';
import { data } from '@Sreelikhith/jobs_in_datascience';

export const main = (container) => {
  const width = container.clientWidth;
  const height = container.clientHeight;

  const svg = select(container)
    .selectAll('svg')
    .data([null])
    .join('svg')
    .attr('width', width)
    .attr('height', height);

  viz(svg, {
    data,
    xValue: (d) => d.job_category,
    xAxisLabelText: 'Job Category',
    xAxisLabelOffset: 30,
    yValue: (d) => d.salary_in_usd,
    yAxisLabelText: 'Average Salary (USD)',
    yAxisLabelOffset: 73,
    circleRadius: 5,
    circleOpacity: 0.7,
    marginTop: 30,
    marginBottom: 90,
    marginLeft: 70,
    marginRight: 30,
    width,
    height,
  });
};